import java.io.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.watson.developer_cloud.http.HttpMediaType;
import com.ibm.watson.developer_cloud.language_translation.v2.model.Language;
import com.ibm.watson.developer_cloud.language_translation.v2.model.TranslationResult;
import com.ibm.watson.developer_cloud.speech_to_text.v1.model.*;
import com.ibm.watson.developer_cloud.speech_to_text.v1.websocket.BaseRecognizeCallback;

/**
 * Servlet implementation class TranslateServlet
 */
@WebServlet("/TranslateServlet")
public class TranslateServlet 
	extends HttpServlet 
{
	private static final 	long 			serialVersionUID 	= 1L;
	public 	static final 	String			COPYRIGHT 			= "Copyright IBM Corp. 2016";
	private	static final 	String			SPEECHREQUEST 		= "Speech2Text";
	private	static final 	String			TRANSLATEREQUEST	= "Translate";
	private					TranslationProxy		translatorService	= null;
	private					S2TProxy	s2tService			= null;
	private					String			inputLanguage		= null;
	private					String			infoLine			= null;
	private static 			String			finalTranscript 	= null;
	
	public void init(ServletConfig cfg) 
			throws ServletException 
	{
		String 		translationPassword 	= "qn2wSVi1D04C";  
		String 		translationUsername 	= "12697890-4c2a-4319-ad6e-2542cec8d7d0";
		String 		s2TPassword 			= "7scI5EnvO1qp";  
		String 		s2TUsername 			= "8e3e90e6-8be6-44ec-93ed-7b613341f1ab";
		String 		vcap 					= "";
		JsonParser 	parser 					= new JsonParser();
		JsonObject	wrapperObject			= null;
		JsonArray	jsonArray				= null;
		JsonObject	serviceObj				= null;
		JsonObject	credentials				= null;

		System.out.println("In the init function");
		
		this.translatorService 	=  new TranslationProxy(translationUsername, translationPassword);
		this.s2tService 		=  new S2TProxy(s2TUsername, s2TPassword);
	}   
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException 
	{
		PrintWriter out 				= response.getWriter();
		String 		message				= "Served at: " + request.getContextPath() + " Watson Cognitive Service Sample from " + request.getServerName();
		String		input				= null;
		String 		targetLanguage 		= request.getParameter("target");
		String		speechOption		= request.getParameter("speech");
		String		translateOption		= request.getParameter("translate");
		String		translatedText		= "";
		Language	originalLanguage	= null;

		if (speechOption != null && speechOption.equalsIgnoreCase(SPEECHREQUEST))
		{
			infoLine = "Check for accuracy of Speech to text";
			input = getMikeAudio();
		}
		if  (translateOption != null && translateOption.equalsIgnoreCase(TRANSLATEREQUEST))
		{
			/** Note dependencies - the order of the following attributes must be maintained **/
			input = request.getParameter("inputText");
			infoLine = formatLanguageWithConfidence(input);
			originalLanguage	= getInputLanguage(inputLanguage);
			translatedText = translate(input, originalLanguage, language(targetLanguage));
		}
		response.setContentType("text/html");
			//  Write out HTML to display
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println(	"<head>");
		out.println(		"<title>The IBM BlueMix Translation Application</title>");
		out.println(		"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");
		out.println(		"<link rel=\"stylesheet\" href=\"theme/myStyle.css\" />");
		out.println(	"</head>");
		out.println("	<body>");
		out.println("		<table>");
		out.println("			<tr>");
		out.println("					<td colspan=\"2\">");
		out.println("						<img class = \"eclipseIcon\" src='images/WorldIcon.png'>");
		out.println("					</td>");
		out.println("					<td colspan=\"2\">");
		out.println("						<h4> John J Andersen <span class=\"blue\">Translation Application</span>. </h4>");
		out.println("					</td>");
		out.println("				</tr>");
		out.println("			<tr>");
		out.println("				<td colspan=\"4\">");
		out.println(					message);
		out.println("				</td>");
		out.println("			</tr>");
		out.println("				<tr align='left'>");
		out.println("					<th colspan=\"2\">Enter text to be translated</th>");
		out.println("					<th colspan=\"2\">Translated text</th>");
		out.println("				</tr>");
		out.println("				<tr>");
		out.println("					<td colspan=\"2\">");
		out.println("						<form action = \"TranslateServlet\">");
		out.println("							<textarea rows = 12 cols = 50 autofocus name = \"inputText\">" + input +  "</textarea><br>");
		out.println("							<input type=\"radio\" name=\"target\" value =\"French\" > French <br>");
		out.println("							<input type=\"radio\" name=\"target\" value =\"Spanish\" checked> Spanish <br>");
		out.println("							<input type=\"radio\" name=\"target\" value =\"English\"> English <br>");
		out.println("							<input type=\"submit\" name = \"translate\" Value = \"Translate\">");
		out.println("							<input type=\"submit\" name = \"speech\" Value = \"Speech2Text\">");
		out.println("						</form>");
		out.println("					</td>");
		out.println("					<td  colspan=\"2\" style='vertical-align:top;'>");
		out.println("						<textarea id = \"outPut\" rows=\"12\" cols=\"50\" readonly name = \"translatedText\">"  + translatedText +  "</textarea>");
		out.println("					</td>");
		out.println("				</tr>");
		out.println("				<tr>");
		out.println("					<!--  This string will identify the language of the input text - it comes from /TranslateServlet -->");
		out.println("					<td style='vertical-align:bottom;'>");
		out.println("						<h3>" + infoLine + "</h3>");
		out.println("					</td>");
		out.println("				</tr>");  
		out.println("			</table>");
		out.println("		</body>");
		out.println("	</html>");
	 }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doGet(request, response);
	}
	
	protected String translate(String input, Language inLang, Language outLang)
	{
		try
		{
		TranslationResult translationResult = translatorService.translate(input, inLang, outLang).execute();
		
		return translationResult.getFirstTranslation();
		}
		catch(Exception e)
		{
			System.out.println("Service not provided");
			return input;
		}
	}
	
	protected String formatLanguageWithConfidence(String input)
	{
		String 	rtnLanguage		= translatorService.identifyMostLikely(input);
		String	formatedString	= null;
		String 	confidence		= null;
		int		languageStart 	= 0;
		int 	confidenceStart	= 0;
		
		confidenceStart = rtnLanguage.indexOf(":", rtnLanguage.indexOf("confidence"));
		languageStart = rtnLanguage.indexOf(":", rtnLanguage.indexOf("language"));
		inputLanguage = rtnLanguage.substring(languageStart + 3, languageStart + 5);  //NOTE this is a GLOBAL attribute
		confidence = rtnLanguage.substring(confidenceStart + 2, confidenceStart + 6);
		formatedString = "Identified Language appears to be: " + inputLanguage + " with a confidence of: " + confidence;
		
		return formatedString;
	}
	protected Language getInputLanguage(String input)
	{
		System.out.println(input);
		switch(input)
		{
		case "es" : return Language.SPANISH;
		case "fr" : return Language.FRENCH;
		case "en" : return Language.ENGLISH;
		default : throw new IllegalArgumentException("Not a supported language");
		}
	}
	
	protected Language language(String language)
	{
		switch(language)
		{
		case "Spanish" : return Language.SPANISH;
		case "French" : return Language.FRENCH;
		case "English" : return Language.ENGLISH;
		default : throw new IllegalArgumentException("Not a supported language");
		}
	}
	
	// Signed PCM AudioFormat with 16kHz, 16 bit sample size, mono  **/
	protected String getMikeAudio()
	{
		String 			output 		= null;
		int 			sampleRate 	= 16000;
		AudioFormat 	format 		= new AudioFormat(sampleRate, 16, 1, true, false);
		DataLine.Info 	info 		= new DataLine.Info(TargetDataLine.class, format);

		finalTranscript = null;
		if (!AudioSystem.isLineSupported(info)) 
		{
			output = "Line not supported";
			return output;
		}
		TargetDataLine line;
		try 
		{
			line = (TargetDataLine)AudioSystem.getLine(info);
			line.open(format);
			line.start();
			AudioInputStream audio = new AudioInputStream(line);
			RecognizeOptions options = new RecognizeOptions.Builder().continuous(true).interimResults(true)
					.inactivityTimeout(5) // use this to stop listening when the speaker pauses, i.e. for 5s
					.contentType(HttpMediaType.AUDIO_RAW + "; rate=" + sampleRate).build();
			s2tService.recognizeUsingWebSocket(audio, options, new BaseRecognizeCallback() 
			{
				@Override
				public void onTranscription(SpeechResults speechResults) 
				{
					System.out.println("onTranscription(): " +speechResults); 
					String transcript = speechResults.getResults().get(0).getAlternatives().get(0).getTranscript();
					if(speechResults.getResults().get(0).isFinal())
					{
						System.out.println("Final Transcript is: " + transcript);
						finalTranscript = transcript;
					}
					else
					{
						System.out.println("Interim Transcript is: " + transcript);
					}
				}
			});
			infoLine = "Listening to your voice for the next 30s...";
			// closing the WebSockets underlying InputStream will close the WebSocket itself.
			while(finalTranscript == null)
			{
				Thread.sleep(1000);
			}
			line.stop();
			line.close();
		} catch (LineUnavailableException e) 
		{
			e.printStackTrace();
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
		System.out.println("Returning Final Transcript: " + finalTranscript);
		return finalTranscript;
	}
}

